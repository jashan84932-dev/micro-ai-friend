package com.micro.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Everything the friend can physically do on the phone.
 * These are generic building blocks (see the screen, tap, type, scroll, open things) –
 * the AI combines them itself, so there is no fixed list of voice commands.
 * Call from a background thread (gestures wait for a callback on the main thread).
 */
class Hands(private val app: Context) {

    @Volatile
    var service: AccessibilityService? = null

    private val ctx: Context get() = service ?: app

    private val needService =
        "The Accessibility service is off, so I can't see or control the screen. " +
            "Ask the user to turn Micro on in Accessibility settings."

    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    // ---------- Seeing the screen ----------

    fun readScreen(): String {
        val svc = service ?: return needService
        val root = svc.rootInActiveWindow ?: return "The screen can't be read right now (maybe it is locked or loading)."
        val sb = StringBuilder("App: ${root.packageName}\n")
        var count = 0

        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (count >= 120 || depth > 30) return
            val label = if (n.isPassword) {
                "(password field)"
            } else {
                listOfNotNull(n.text?.toString()?.take(80), n.contentDescription?.toString()?.take(80))
                    .filter { it.isNotBlank() }
                    .joinToString(" | ")
            }
            val interesting = label.isNotEmpty() || n.isClickable || n.isEditable || n.isScrollable
            if (interesting && n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                sb.append("- ")
                if (label.isNotEmpty()) sb.append('"').append(label).append('"') else sb.append("(no label)")
                val flags = ArrayList<String>()
                if (n.isClickable) flags.add("clickable")
                if (n.isEditable) flags.add("editable")
                if (n.isScrollable) flags.add("scrollable")
                if (n.isChecked) flags.add("checked")
                if (flags.isNotEmpty()) sb.append(" [").append(flags.joinToString(",")).append("]")
                sb.append(" @").append(r.centerX()).append(',').append(r.centerY()).append('\n')
                count++
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c, depth + 1)
            }
        }

        walk(root, 0)
        if (count == 0) sb.append("(nothing readable on screen – it may be a game or video. Try tap with coordinates.)\n")
        if (count >= 120) sb.append("(list cut off – scroll for more)\n")
        sb.append("Coordinates are x,y in pixels of the screen centre of each item.")
        return sb.toString()
    }

    // ---------- Touching the screen ----------

    fun click(label: String): String {
        val svc = service ?: return needService
        val root = svc.rootInActiveWindow ?: return "The screen can't be read right now."
        if (label.isBlank()) return "No label given."
        for (node in root.findAccessibilityNodeInfosByText(label)) {
            var n: AccessibilityNodeInfo? = node
            while (n != null && !n.isClickable) n = n.parent
            if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return "Clicked \"$label\"."
            }
        }
        return "Couldn't find a clickable \"$label\". Use read_screen and tap by coordinates instead."
    }

    fun tap(x: Int, y: Int): String {
        if (x < 0 || y < 0) return "Invalid coordinates."
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return gesture(p, 60L)
    }

    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Int): String {
        if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) return "Invalid coordinates."
        val p = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        return gesture(p, durationMs.toLong().coerceIn(100L, 2000L))
    }

    private fun gesture(path: Path, durationMs: Long): String {
        val svc = service ?: return needService
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val sent = svc.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok.set(true)
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        if (!sent) return "The gesture could not be sent."
        latch.await(3, TimeUnit.SECONDS)
        return if (ok.get()) "Done." else "The gesture was cancelled."
    }

    // ---------- Typing and scrolling ----------

    /** Replaces the text in the focused box (or the first text box on screen). */
    fun typeText(text: String): String {
        val svc = service ?: return needService
        val root = svc.rootInActiveWindow ?: return "The screen can't be read right now."
        var field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (field == null) {
            field = findFirst(root) { it.isEditable && it.isVisibleToUser }
            field?.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        }
        if (field == null) return "No text box found. Tap one first."
        if (field.isPassword) return "That is a password field. I don't type passwords – ask the user to type it."
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed." else "Couldn't type there."
    }

    fun scroll(down: Boolean): String {
        val svc = service ?: return needService
        val root = svc.rootInActiveWindow ?: return "The screen can't be read right now."
        val node = findFirst(root) { it.isScrollable } ?: return "Nothing scrollable on this screen."
        val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (node.performAction(action)) "Scrolled." else "Couldn't scroll (maybe already at the end)."
    }

    fun press(button: String): String {
        val svc = service ?: return needService
        val action = when (button.lowercase(Locale.ROOT)) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            else -> return "Unknown button. Use back, home, recents, notifications or quick_settings."
        }
        return if (svc.performGlobalAction(action)) "Pressed $button." else "Couldn't press $button."
    }

    private fun findFirst(
        n: AccessibilityNodeInfo,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (pred(n)) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findFirst(c, pred)?.let { return it }
        }
        return null
    }

    // ---------- Opening things ----------

    fun openApp(name: String): String {
        val query = name.trim().lowercase(Locale.getDefault())
        if (query.isEmpty()) return "No app name given."
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        fun label(i: android.content.pm.ResolveInfo) = i.loadLabel(pm).toString().lowercase(Locale.getDefault())
        val match = apps.firstOrNull { label(it) == query }
            ?: apps.firstOrNull { label(it).contains(query) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase(Locale.ROOT).contains(query) }
            ?: return "No installed app matches \"$name\"."
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "That app can't be launched."
        launch(intent)
        return "Opened ${match.loadLabel(pm)}."
    }

    private val allowedSchemes = setOf(
        "http", "https", "tel", "sms", "smsto", "mailto", "geo",
        "google.navigation", "market", "whatsapp", "vnd.youtube", "spotify"
    )

    fun openUri(uri: String): String {
        val u = Uri.parse(uri.trim())
        val scheme = u.scheme?.lowercase(Locale.ROOT) ?: return "That isn't a valid link."
        if (scheme !in allowedSchemes) return "That kind of link isn't allowed."
        return try {
            launch(Intent(Intent.ACTION_VIEW, u))
            when (scheme) {
                "tel" -> "Dialer opened with the number. The call is NOT placed until the user presses call."
                "sms", "smsto", "mailto", "whatsapp" -> "Opened the draft. Nothing is sent until the user presses send."
                else -> "Opened."
            }
        } catch (e: ActivityNotFoundException) {
            "No app on this phone can open that."
        }
    }

    fun webSearch(query: String): String {
        if (query.isBlank()) return "No search text given."
        return openUri("https://www.google.com/search?q=" + Uri.encode(query))
    }

    fun setAlarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23 || minute !in 0..59) return "That time is invalid."
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        return try {
            launch(i)
            String.format(Locale.ENGLISH, "Alarm set for %02d:%02d.", hour, minute)
        } catch (e: ActivityNotFoundException) {
            "No clock app found."
        }
    }

    fun setTimer(seconds: Int, label: String): String {
        if (seconds !in 1..86400) return "Timer must be between 1 second and 24 hours."
        val i = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        return try {
            launch(i)
            "Timer started for $seconds seconds."
        } catch (e: ActivityNotFoundException) {
            "No clock app found."
        }
    }
}
