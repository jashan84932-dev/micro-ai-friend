package com.micro.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var assistant: Assistant
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var apiKey: EditText
    private lateinit var friendName: EditText
    private lateinit var userName: EditText
    private lateinit var customVoice: CheckBox
    private lateinit var voiceKey: EditText
    private lateinit var voiceId: EditText
    private lateinit var typed: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assistant = Assistant.get(this)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 72, 40, 40)
        }

        fun label(text: String, size: Float = 14f) = TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, 24, 0, 4)
        }

        fun field(hint: String, secret: Boolean = false, value: String = "") = EditText(this).apply {
            this.hint = hint
            setText(value)
            setSingleLine(true)
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else InputType.TYPE_CLASS_TEXT
        }

        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        }

        box.addView(TextView(this).apply { text = "Micro – tumhara dost"; textSize = 28f })
        statusView = TextView(this).apply { textSize = 16f; setPadding(0, 8, 0, 8) }
        box.addView(statusView)

        // --- Talk controls ---
        box.addView(button("🎤 Baat shuru karo") {
            if (MicroService.instance == null) {
                Toast.makeText(this, "Accessibility me Micro ON karo to main phone bhi chala sakta hoon", Toast.LENGTH_LONG).show()
            }
            assistant.startConversation()
        })
        box.addView(button("Ruko / Stop") { assistant.stopConversation() })

        typed = field("Ya yahan type karke bhejo")
        box.addView(typed)
        box.addView(button("Bhejo") {
            val t = typed.text.toString()
            typed.setText("")
            assistant.sendText(t)
        })

        logScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 700)
        }
        logView = TextView(this).apply { textSize = 15f; setPadding(8, 8, 8, 8) }
        logScroll.addView(logView)
        box.addView(label("Baatcheet"))
        box.addView(logScroll)

        // --- Setup ---
        box.addView(label("Setup", 20f))
        box.addView(button("1. Microphone allow karo") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        box.addView(button("2. Accessibility me Micro ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        box.addView(label("Claude API key (OPTIONAL – khali chhod do, free dimaag chalega)"))
        apiKey = field("khali chhod sakte ho", secret = true, value = Prefs.apiKey)
        box.addView(apiKey)

        box.addView(label("Dost ka naam"))
        friendName = field("Micro", value = Prefs.friendName)
        box.addView(friendName)

        box.addView(label("Tumhara naam"))
        userName = field("Tumhara naam", value = Prefs.userName)
        box.addView(userName)

        box.addView(label("Custom awaaz (ElevenLabs)", 16f))
        customVoice = CheckBox(this).apply {
            text = "Apni custom voice use karo"
            isChecked = Prefs.customVoice
        }
        box.addView(customVoice)
        voiceKey = field("ElevenLabs API key", secret = true, value = Prefs.voiceKey)
        box.addView(voiceKey)
        voiceId = field("Voice ID", value = Prefs.voiceId)
        box.addView(voiceId)

        box.addView(button("Save settings") { saveSettings() })
        box.addView(button("Sab kuch bhool jao (memory delete)") {
            Memory.clearAll()
            Toast.makeText(this, "Memory saaf ho gayi", Toast.LENGTH_SHORT).show()
        })

        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun saveSettings() {
        Prefs.apiKey = apiKey.text.toString()
        Prefs.friendName = friendName.text.toString()
        Prefs.userName = userName.text.toString()
        Prefs.customVoice = customVoice.isChecked
        Prefs.voiceKey = voiceKey.text.toString()
        Prefs.voiceId = voiceId.text.toString()
        Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        assistant.onChange = { refresh() }
        refresh()
        if (!assistant.voice.hindiAvailable) {
            Toast.makeText(
                this,
                "Phone me Hindi voice nahi mili. Settings > Text-to-speech me Hindi voice download karo.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onPause() {
        assistant.onChange = null
        super.onPause()
    }

    private fun refresh() {
        val hands = if (MicroService.instance != null) "phone control ON" else "phone control OFF"
        statusView.text = "${assistant.status}  •  $hands"
        logView.text = assistant.transcript.toString()
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }
}
