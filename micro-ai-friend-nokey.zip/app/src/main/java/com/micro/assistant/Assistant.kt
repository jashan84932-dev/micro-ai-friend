package com.micro.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Ties everything together: listens (Hindi), thinks (Brain), speaks (Voice), and keeps
 * a continuous conversation going until you say bye or press Stop.
 */
class Assistant private constructor(private val app: Context) {

    companion object {
        @Volatile private var inst: Assistant? = null
        fun get(ctx: Context): Assistant {
            val a = ctx.applicationContext
            Prefs.init(a)
            return inst ?: synchronized(this) { inst ?: Assistant(a).also { inst = it } }
        }
        private val STOP_WORDS = listOf("बाय", "bye", "बंद करो", "stop", "अलविदा", "बस करो", "गुड नाइट", "good night")
    }

    val hands = Hands(app)
    private val brain = Brain(hands)
    val voice = Voice(app)
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var silences = 0
    private var generation = 0

    @Volatile var active = false
        private set
    val transcript = StringBuilder()
    var onChange: (() -> Unit)? = null // called on the main thread
    var status = "तैयार"
        private set

    private fun log(line: String) {
        transcript.append(line).append("\n\n")
        if (transcript.length > 20000) transcript.delete(0, transcript.length - 15000)
        onChange?.invoke()
    }

    private fun state(s: String) {
        status = s
        onChange?.invoke()
    }

    // ---------- Public controls ----------

    fun startConversation() {
        main.post {
            if (active) return@post
            active = true
            silences = 0
            listen()
        }
    }

    fun stopConversation() {
        main.post {
            active = false
            generation++
            recognizer?.cancel()
            voice.stop()
            state("तैयार")
        }
    }

    /** A typed message (works even without the microphone). */
    fun sendText(text: String) {
        if (text.isBlank()) return
        main.post {
            recognizer?.cancel()
            log("आप: $text")
            think(text)
        }
    }

    // ---------- Listening ----------

    private fun listen() {
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            active = false
            log("पहले microphone की permission दो।")
            state("तैयार")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            active = false
            log("इस फोन में speech recognition नहीं मिला।")
            state("तैयार")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        r.setRecognitionListener(listener)
        recognizer = r
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
        }
        state("सुन रहा हूँ…")
        r.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) {
                retryOrGiveUp()
                return
            }
            silences = 0
            heard(text.trim())
        }

        override fun onError(error: Int) {
            if (!active) return
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                active = false
                log("पहले microphone की permission दो।")
                state("तैयार")
                return
            }
            retryOrGiveUp()
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun retryOrGiveUp() {
        if (!active) return
        silences++
        if (silences >= 3) {
            active = false
            state("तैयार")
            log("(कुछ सुनाई नहीं दिया, मैं रुक गया। जब बात करनी हो, Start दबा दो।)")
        } else {
            main.postDelayed({ if (active) listen() }, 500)
        }
    }

    private fun heard(text: String) {
        log("आप: $text")
        val lower = text.lowercase(Locale.getDefault())
        if (text.length < 25 && STOP_WORDS.any { lower.contains(it) }) {
            active = false
            val bye = "ठीक है, बाय! जब मन करे, बुला लेना।"
            log("${Prefs.friendName}: $bye")
            state("बोल रहा हूँ…")
            voice.speak(bye) { state("तैयार") }
            return
        }
        think(text)
    }

    // ---------- Thinking and speaking ----------

    private fun think(text: String) {
        val gen = ++generation
        state("सोच रहा हूँ…")
        Thread {
            val reply = brain.reply(text)
            main.post {
                if (gen != generation) return@post
                log("${Prefs.friendName}: $reply")
                state("बोल रहा हूँ…")
                voice.speak(reply) {
                    if (active) listen() else state("तैयार")
                }
            }
        }.start()
    }
}
