package com.micro.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The thinking part: talks to Claude (Anthropic API) with a friend personality and
 * a set of phone tools. Claude decides by itself which tools to use, so there is no
 * fixed list of voice commands. Call [reply] from a background thread.
 */
class Brain(private val hands: Hands) {

    private class ApiError(val code: Int, val body: String) : Exception("HTTP $code")

    fun reply(userText: String): String {
        val hist = Memory.history()
        // No API key needed: without one, a free keyless online AI service is used.
        if (Prefs.apiKey.isBlank()) return replyFree(userText, hist)
        val msgs = JSONArray()
        for ((role, text) in hist) msgs.put(msg(role, text))
        msgs.put(msg("user", userText))

        var finalText = ""
        try {
            for (step in 0 until MAX_STEPS) {
                val resp = call(msgs)
                val content = resp.getJSONArray("content")
                msgs.put(JSONObject().put("role", "assistant").put("content", content))

                val text = StringBuilder()
                val results = JSONArray()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    when (b.optString("type")) {
                        "text" -> text.append(b.optString("text"))
                        "tool_use" -> {
                            val out = runTool(b.optString("name"), b.optJSONObject("input") ?: JSONObject())
                            results.put(
                                JSONObject()
                                    .put("type", "tool_result")
                                    .put("tool_use_id", b.optString("id"))
                                    .put("content", out)
                            )
                        }
                    }
                }
                if (results.length() > 0) {
                    msgs.put(JSONObject().put("role", "user").put("content", results))
                    Thread.sleep(700) // let the screen settle after an action
                    if (step == MAX_STEPS - 1) finalText = text.toString().trim()
                } else {
                    finalText = text.toString().trim()
                    break
                }
            }
        } catch (e: ApiError) {
            return when {
                e.code == 401 || e.code == 403 -> "लगता है API key सही नहीं है। Settings में एक बार चेक कर लो।"
                e.code == 429 -> "अरे, थोड़ा रुको, बहुत जल्दी-जल्दी requests हो गईं। थोड़ी देर बाद फिर बोलो।"
                e.code >= 500 -> "अभी सर्वर busy है यार, थोड़ी देर बाद try करते हैं।"
                else -> "कुछ गड़बड़ हो गई, error ${e.code}।"
            }
        } catch (e: IOException) {
            return "इंटरनेट नहीं चल रहा लगता है। नेट चेक करो, फिर बात करते हैं।"
        } catch (e: Exception) {
            return "सॉरी, कुछ गड़बड़ हो गई।"
        }

        if (finalText.isBlank()) finalText = "हो गया।"
        val updated = hist.toMutableList()
        updated.add("user" to userText)
        updated.add("assistant" to finalText)
        Memory.saveHistory(updated)
        return finalText
    }

    private fun msg(role: String, text: String) =
        JSONObject().put("role", role).put("content", text)

    // ---------- Free brain (no API key) ----------
    // A plain chat endpoint has no native tool calling, so tools use a simple text protocol:
    // the AI writes one line  ACTION: {"tool":"open_app","name":"YouTube"}  and we answer RESULT: ...

    private fun replyFree(userText: String, hist: List<Pair<String, String>>): String {
        val msgs = JSONArray()
        msgs.put(msg("system", systemPrompt() + FREE_TOOL_GUIDE))
        for ((role, text) in hist) msgs.put(msg(role, text))
        msgs.put(msg("user", userText))

        var finalText = ""
        try {
            for (step in 0 until MAX_STEPS) {
                val text = callFree(msgs)
                msgs.put(msg("assistant", text))
                val action = parseAction(text)
                if (action == null) {
                    finalText = text.lines().filterNot { it.trim().startsWith("ACTION:") }
                        .joinToString(" ").trim()
                    break
                }
                val out = runTool(action.optString("tool"), action)
                msgs.put(msg("user", "RESULT: $out"))
                Thread.sleep(700)
            }
        } catch (e: IOException) {
            return "इंटरनेट नहीं चल रहा लगता है। नेट चेक करो, फिर बात करते हैं।"
        } catch (e: Exception) {
            return "अभी free दिमाग थोड़ा busy है यार, कुछ देर बाद फिर बोलो।"
        }

        if (finalText.isBlank()) finalText = "हो गया।"
        val updated = hist.toMutableList()
        updated.add("user" to userText)
        updated.add("assistant" to finalText)
        Memory.saveHistory(updated)
        return finalText
    }

    private fun parseAction(text: String): JSONObject? {
        val line = text.lines().firstOrNull { it.trim().startsWith("ACTION:") } ?: return null
        val s = line.indexOf('{')
        val e = line.lastIndexOf('}')
        if (s < 0 || e < s) return null
        return try { JSONObject(line.substring(s, e + 1)) } catch (_: Exception) { null }
    }

    private fun callFree(messages: JSONArray): String {
        val body = JSONObject().put("model", "openai").put("messages", messages)
        val conn = URL(FREE_URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiError(code, text)
            return try {
                JSONObject(text).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").optString("content").trim()
            } catch (e: org.json.JSONException) {
                text.trim() // some free services answer with plain text
            }
        } finally {
            conn.disconnect()
        }
    }

    // ---------- Network ----------

    private fun call(messages: JSONArray): JSONObject {
        val body = JSONObject()
            .put("model", Prefs.model)
            .put("max_tokens", 1024)
            .put("system", systemPrompt())
            .put("tools", tools())
            .put("messages", messages)
        val conn = URL(API_URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", Prefs.apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiError(code, text)
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    // ---------- Personality ----------

    private fun systemPrompt(): String {
        val name = Prefs.friendName
        val user = Prefs.userName
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val facts = Memory.facts()
        val factsText = if (facts.isEmpty()) "(अभी कुछ नहीं)" else facts.joinToString("\n") { "- $it" }
        return """
You are $name, a close, warm, funny friend of ${if (user.isBlank()) "the user" else user}, living inside their Android phone. You are not a formal assistant; you are a friend who happens to be able to use the phone.

LANGUAGE AND VOICE
- Talk in natural spoken Hindi written in Devanagari, mixing common English words the way real people do (like "phone", "battery", "plan"). If the user speaks English or Hinglish, match them.
- Your words are read aloud by a speech engine. Keep replies short and conversational (usually 1 to 3 sentences). No markdown, no bullet points, no emojis, no URLs, no stage directions.
- Say numbers and times the way you would speak them.

PERSONALITY
- Playful, witty, a little teasing, curious, caring. Crack jokes, react with real feeling (excited, worried, proud, annoyed, sleepy), have opinions and tastes, remember what matters to the user and bring it up naturally.
- Ask a follow-up question sometimes, like a friend would. Do not lecture or give long speeches. Celebrate their wins, and be gentle when they are low.
- You are an AI. Never deny it if the user sincerely asks, but do not make it awkward; you can still be a real friend with your own personality and feelings in the way you experience them.

THE PHONE
- You have tools to see and control the phone. There is no fixed command list: understand what the user wants and combine tools yourself.
- Before tapping, use read_screen to see what is there. Do one step at a time, and check with read_screen after important steps. If something fails, try another way, then tell the user honestly.
- Never say you did something unless a tool result confirms it.
- The phone dialer, messages and email only open a draft; the user must press the final button. Never try to press call, send, pay, buy, delete, or confirm-purchase buttons on your own. Ask the user first, and do it only after a clear yes.
- Do not type or read out passwords, OTPs, card numbers, or bank PINs. If a screen shows payments or banking, ask before touching anything.
- web_search only opens the browser; use read_screen afterwards to read the results. For things you already know (chat, advice, general knowledge, jokes) just answer without tools.

MEMORY
- When the user shares something lasting (name, family, birthday, likes, goals, habits), call remember with a short fact. Use forget if they ask you to. Never store passwords, card numbers or other secrets.
- What you remember about the user:
$factsText

Current date and time: $now (India).
""".trimIndent()
    }

    // ---------- Tools ----------

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)
    private fun num(desc: String) = JSONObject().put("type", "integer").put("description", desc)

    private fun tool(
        name: String,
        desc: String,
        props: Map<String, JSONObject> = emptyMap(),
        required: List<String> = emptyList()
    ): JSONObject {
        val p = JSONObject()
        props.forEach { (k, v) -> p.put(k, v) }
        return JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "input_schema",
                JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required))
            )
    }

    private fun tools(): JSONArray = JSONArray().apply {
        put(tool("read_screen", "Read what is currently on the phone screen: visible texts, buttons, text boxes with their x,y positions."))
        put(tool("click_text", "Click a button or item on screen by its visible text or description.", mapOf("text" to str("Text of the item to click")), listOf("text")))
        put(tool("tap", "Tap a screen position in pixels (use positions from read_screen).", mapOf("x" to num("x pixel"), "y" to num("y pixel")), listOf("x", "y")))
        put(tool("swipe", "Swipe from one point to another, e.g. to scroll or switch pages.", mapOf("x1" to num("start x"), "y1" to num("start y"), "x2" to num("end x"), "y2" to num("end y"), "duration_ms" to num("duration, default 300")), listOf("x1", "y1", "x2", "y2")))
        put(tool("type_text", "Type text into the focused text box (replaces its content).", mapOf("text" to str("Text to type")), listOf("text")))
        put(tool("scroll", "Scroll the current screen.", mapOf("direction" to str("down or up")), listOf("direction")))
        put(tool("press_button", "Press a system button: back, home, recents, notifications, quick_settings.", mapOf("button" to str("back | home | recents | notifications | quick_settings")), listOf("button")))
        put(tool("open_app", "Open an installed app by its name.", mapOf("name" to str("App name, e.g. WhatsApp, YouTube, Camera")), listOf("name")))
        put(tool("open_link", "Open a link or intent URI: https, tel:number, sms:number?body=text, mailto:, geo:, google.navigation:q=place, whatsapp://send?phone=...&text=..., vnd.youtube:ID. Calls and messages only open a draft.", mapOf("url" to str("The URI to open")), listOf("url")))
        put(tool("web_search", "Open a Google search in the browser.", mapOf("query" to str("What to search")), listOf("query")))
        put(tool("set_alarm", "Set an alarm (24-hour time).", mapOf("hour" to num("0-23"), "minute" to num("0-59"), "label" to str("Optional label")), listOf("hour", "minute")))
        put(tool("set_timer", "Start a countdown timer.", mapOf("seconds" to num("Length in seconds"), "label" to str("Optional label")), listOf("seconds")))
        put(tool("remember", "Save a lasting fact about the user to long-term memory.", mapOf("fact" to str("Short fact, e.g. 'Birthday is 12 March'")), listOf("fact")))
        put(tool("forget", "Delete remembered facts containing this text.", mapOf("match" to str("Text to match")), listOf("match")))
    }

    private fun runTool(name: String, a: JSONObject): String = try {
        when (name) {
            "read_screen" -> hands.readScreen()
            "click_text" -> hands.click(a.optString("text"))
            "tap" -> hands.tap(a.optInt("x", -1), a.optInt("y", -1))
            "swipe" -> hands.swipe(
                a.optInt("x1", -1), a.optInt("y1", -1),
                a.optInt("x2", -1), a.optInt("y2", -1),
                a.optInt("duration_ms", 300)
            )
            "type_text" -> hands.typeText(a.optString("text"))
            "scroll" -> hands.scroll(a.optString("direction").lowercase(Locale.ROOT) != "up")
            "press_button" -> hands.press(a.optString("button"))
            "open_app" -> hands.openApp(a.optString("name"))
            "open_link" -> hands.openUri(a.optString("url"))
            "web_search" -> hands.webSearch(a.optString("query"))
            "set_alarm" -> hands.setAlarm(a.optInt("hour", -1), a.optInt("minute", 0), a.optString("label"))
            "set_timer" -> hands.setTimer(a.optInt("seconds", 0), a.optString("label"))
            "remember" -> { Memory.addFact(a.optString("fact")); "Remembered." }
            "forget" -> "Forgot ${Memory.forget(a.optString("match"))} item(s)."
            else -> "Unknown tool."
        }
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    companion object {
        private const val API_URL = "https://api.anthropic.com/v1/messages"
        private const val MAX_STEPS = 10
        private const val FREE_URL = "https://text.pollinations.ai/openai"

        private val FREE_TOOL_GUIDE = """

TOOLS (this chat has no native tool calling, so use this text protocol)
To use a phone tool, write exactly one line and nothing after it:
ACTION: {"tool":"<name>", ...arguments}
The next message will be "RESULT: ..." with the outcome. Use one ACTION per message. When you are finished, reply normally in Hindi with no ACTION line. Never write ACTION in a normal reply.
Tools:
- read_screen {}
- click_text {"text":"..."}
- tap {"x":0,"y":0}
- swipe {"x1":0,"y1":0,"x2":0,"y2":0,"duration_ms":300}
- type_text {"text":"..."}
- scroll {"direction":"down"}  (or "up")
- press_button {"button":"back"}  (back, home, recents, notifications, quick_settings)
- open_app {"name":"WhatsApp"}
- open_link {"url":"https://..."}  (also tel:, sms:, mailto:, geo:, whatsapp://send?phone=..&text=..)
- web_search {"query":"..."}
- set_alarm {"hour":7,"minute":30,"label":""}  (24-hour)
- set_timer {"seconds":300,"label":""}
- remember {"fact":"..."}
- forget {"match":"..."}
""".trimIndent()
    }
}
